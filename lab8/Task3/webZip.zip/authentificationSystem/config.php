<?php

return [
    'db_name' => 'php-auth-demo',
    'db_host' => '127.0.0.1',
    'db_user' => 'root',
    'db_pass' => '6484915',
];