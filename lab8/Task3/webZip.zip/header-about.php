<!DOCTYPE html>
<html>

<head>
    <title>Header</title>
    <link rel="stylesheet" href="/html/Web/style.css">
</head>

<body>


    <div class="header-about" style="
    margin-bottom: 100px;
">
        <div class="container">

            <?php include '/var/www/html/Web/header.php'; ?>
        </div>

    </div>


</body>

</html>